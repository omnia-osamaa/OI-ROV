class ApiConfig {
  static const String apiUrl = 'http://192.168.43.238:8000';
}
