const String Name = "Omnia Osama";
const String Email = "omnya.osama77@gmail.com";
const String Committee = "Software member";
const String Logout = "Logout";
const String Edit = "Edit Profile";

const String Menu2 = "Contact Us";
const String Menu3 = "Add another account";
const String Menu4 = "Logout"; 
