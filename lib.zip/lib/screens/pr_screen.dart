import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:oirov13/Constants/api_config.dart';

class PRScreen extends StatefulWidget {
  const PRScreen({super.key});

  @override
  _PRScreenState createState() => _PRScreenState();
}

class _PRScreenState extends State<PRScreen> {
  bool showAbout = true;
  Map<String, dynamic>? aboutUsData;
  bool isLoading = true;

  Future<void> fetchData() async {
    const String url = "${ApiConfig.apiUrl}/api/client/committee";
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        setState(() {
          aboutUsData = responseData['data']['data'][5]['aboutUs'];
          isLoading = false;
        });
      } else {
        throw Exception("Failed to load data");
      }
    } catch (error) {
      print("Error fetching data: $error");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  String formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return DateFormat('MMM, yyyy').format(date);
    } catch (e) {
      return 'Invalid date';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(
          color: Colors.amber,
        ),
      )
          : SingleChildScrollView(
        child: Column(
          children: [
            buildHeader(context, aboutUsData?['image'] ?? ''),
            if (showAbout && aboutUsData != null) ...[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  aboutUsData!['description'] ?? "No description",
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget buildHeader(BuildContext context, String imagePath) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.2,
            child: Image.asset(
              'assets/img/PPR.png',
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            top: 10,
            left: 10,
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios,
                  color: Colors.white, size: 30),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}
