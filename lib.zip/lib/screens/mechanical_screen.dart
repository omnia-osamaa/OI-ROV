import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:oirov13/Constants/api_config.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';

class MechanicalScreen extends StatefulWidget {
  const MechanicalScreen({super.key});

  @override
  MechanicalScreenState createState() => MechanicalScreenState();
}

class MechanicalScreenState extends State<MechanicalScreen> {
  bool showAbout = true;
  bool showVideos = false;
  Map<String, dynamic>? aboutUsData;
  List<dynamic>? videoCourses;
  bool isLoading = true;

  Future<void> fetchData() async {
    const String url = "${ApiConfig.apiUrl}/api/client/committee";
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        setState(() {
          aboutUsData = responseData['data']['data'][2]['aboutUs'];
          videoCourses = responseData['data']['data'][2]['courses'];

          isLoading = false;
        });
      } else {
        throw Exception("Failed to load data");
      }
    } catch (error) {
      print("Error fetching data: $error");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  String formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return DateFormat('MMM, yyyy').format(date);
    } catch (e) {
      return 'Invalid date';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(
          color: Colors.amber,
        ),
      )
          : SingleChildScrollView(
        child: Column(
          children: [
            buildHeader(context, aboutUsData?['image'] ?? ''),
            buildTabSwitcher(),
            if (showAbout && aboutUsData != null) ...[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  aboutUsData!['description'] ?? "No description",
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
            if (showVideos && videoCourses != null) ...[
              ...videoCourses!.map((course) {
                return buildVideoContainer(
                  "courses/${course['id']}.png", 
                  course['course_name'],
                  formatDate(course['date']),
                  course['link'],
                  context,
                );
              }).toList(),
            ],
          ],
        ),
      ),
    );
  }

  Widget buildHeader(BuildContext context, String imagePath) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.2,
            child: Image.asset(
              'assets/img/VM.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            top: 10,
            left: 10,
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios,
                  color: Colors.white, size: 30),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildTabSwitcher() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          buildTab("About", showAbout, () {
            setState(() {
              showAbout = true;
              showVideos = false;
            });
          }),
          const SizedBox(width: 20),
          buildTab("Videos", showVideos, () {
            setState(() {
              showVideos = true;
              showAbout = false;
            });
          }),
        ],
      ),
    );
  }

  Widget buildTab(String title, bool isActive, VoidCallback onTap) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      width: 120,
      decoration: BoxDecoration(
        color: isActive ? Colors.amber : Colors.black,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.amber,
          width: 2,
        ),
      ),
      child: TextButton(
        onPressed: onTap,
        child: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.black : Colors.amber,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget buildVideoContainer(
      String imagePath, String title, String date, String link, BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final Uri url = Uri.parse(link);
        if (await canLaunchUrl(url)) {
          await launchUrl(url, mode: LaunchMode.externalApplication);
        } else {
          if (kDebugMode) {
            print("Could not launch $link");
          }
        }
      },
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.9,
                    height: 120,
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(12),
                        topRight: Radius.circular(12),
                      ),
                      child: Image.asset(
                        'assets/img/VM.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                          return const Center(
                            child: Icon(
                              Icons.image_not_supported,
                              color: Colors.grey,
                              size: 50,
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.center,
                      child: Icon(
                        Icons.play_circle_fill,
                        color: Colors.white.withOpacity(0.8),
                        size: 50,
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.9,
                padding: const EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                  color: Colors.grey[900]?.withOpacity(0.8),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(12),
                    bottomRight: Radius.circular(12),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      date,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
